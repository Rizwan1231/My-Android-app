# Starlight - Hotel Search App

Starlight is a modern Jetpack Compose Android app for hotel searching, price comparison, and deal discovery.

## Features
- **Redesigned UI**: Matches the modern hotel search design with category tabs, hero header, search card, popular destinations, top picks, wishlist, and bottom navigation bar.
- **Hotel Search**: Real-time searching across hundreds of hotel providers using the Hotella API.
- **Deals & Pricing**: Direct price comparison across booking options.
- **Wishlist & Search History**: Save favorite stays and access recent searches offline via Room Database.
