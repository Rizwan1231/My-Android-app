package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.data.HistoryRepository
import com.example.data.SavedHotel
import com.example.data.SearchHistory
import com.example.network.ApiConfig
import com.example.network.RetrofitClient
import com.example.network.models.BookingOption
import com.example.network.models.Hotel
import com.example.network.models.SearchRequest
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

sealed class LocationState {
    object Initial : LocationState()
    object NetworkError : LocationState()
    data class Loaded(val isoCode: String, val currency: String, val placeholder: String) : LocationState()
}

sealed class SearchUiState {
    object Initial : SearchUiState()
    data class Loading(val message: String) : SearchUiState()
    data class Success(
        val searchId: String,
        val hotels: List<Hotel>,
        val currentPage: Int,
        val totalPages: Int,
        val totalItems: Int,
        val hasNext: Boolean = false,
        val unfilteredTotal: Int? = null,
        val sourceTotal: Int? = null,
        val totalIsComplete: Boolean? = null,
        val filtersActive: Boolean? = null,
        val isLoadingMore: Boolean = false
    ) : SearchUiState()
    data class Error(val message: String, val isPaginationError: Boolean = false, val failedPage: Int = 1) : SearchUiState()
}

sealed class PricingUiState {
    object Initial : PricingUiState()
    object Loading : PricingUiState()
    data class Success(val bookingOptions: List<BookingOption>) : PricingUiState()
    data class Error(val message: String) : PricingUiState()
}

class SearchViewModel(application: Application) : AndroidViewModel(application) {
    private val repository: HistoryRepository

    init {
        val database = AppDatabase.getDatabase(application)
        repository = HistoryRepository(database.searchHistoryDao(), database.wishlistDao())
    }

    val recentHistory: StateFlow<List<SearchHistory>> = repository.recentHistory.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val wishlist: StateFlow<List<SavedHotel>> = repository.wishlist.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    fun clearHistory() {
        viewModelScope.launch {
            repository.clear()
        }
    }

    fun toggleWishlist(hotel: Hotel) {
        val hotelRef = hotel.hotelRef ?: hotel.name
        viewModelScope.launch {
            val savedHotel = SavedHotel(
                hotelRef = hotelRef,
                name = hotel.name,
                address = hotel.address,
                imageUrl = hotel.imageUrl,
                rating = hotel.rating,
                reviewCount = hotel.reviewCount,
                nightlyPriceDisplay = hotel.nightlyPriceDisplay ?: hotel.price?.let { "$it/night" },
                currency = hotel.currency
            )
            repository.toggleWishlist(savedHotel)
        }
    }

    private val _locationState = MutableStateFlow<LocationState>(LocationState.Initial)
    val locationState: StateFlow<LocationState> = _locationState.asStateFlow()

    private val _uiState = MutableStateFlow<SearchUiState>(SearchUiState.Initial)
    val uiState: StateFlow<SearchUiState> = _uiState.asStateFlow()

    private val _pricingUiState = MutableStateFlow<PricingUiState>(PricingUiState.Initial)
    val pricingUiState: StateFlow<PricingUiState> = _pricingUiState.asStateFlow()

    private var currentSearchId: String? = null

    var selectedCategory: String = "Hotels"
    var cachedCurrency: String = "USD"
    var cachedCountry: String = "us"
    var cachedQuery: String = ""
    var cachedCheckIn: String = java.time.LocalDate.now().plusDays(1).toString()
    var cachedCheckOut: String = java.time.LocalDate.now().plusDays(3).toString()
    var cachedAdults: Int = 2
    var cachedChildren: Int = 0
    var cachedRooms: Int = 1
    var cachedSortBy: String? = null
    var cachedMinPrice: Double? = null
    var cachedMaxPrice: Double? = null

    val countries = java.util.Locale.getISOCountries().map {
        val locale = java.util.Locale("", it)
        it.lowercase() to locale.displayCountry
    }.toMap()

    val countryToCurrency = java.util.Locale.getISOCountries().mapNotNull { country ->
        try {
            val currency = java.util.Currency.getInstance(java.util.Locale("", country))
            country.lowercase() to currency.currencyCode
        } catch (e: Exception) { null }
    }.toMap()

    val currencies = countryToCurrency.values.distinct().sorted()

    init {
        initDefaults()
    }

    private fun getPlaceholderForCountry(countryCode: String): String {
        return when (countryCode.lowercase()) {
            "us" -> "e.g. New York, United States"
            "uk", "gb" -> "e.g. London, United Kingdom"
            "in" -> "e.g. New Delhi, India"
            "pk" -> "e.g. Lahore, Pakistan"
            "fr" -> "e.g. Paris, France"
            "de" -> "e.g. Berlin, Germany"
            "ca" -> "e.g. Toronto, Canada"
            "au" -> "e.g. Sydney, Australia"
            "jp" -> "e.g. Tokyo, Japan"
            "ae" -> "e.g. Dubai, United Arab Emirates"
            else -> "e.g. Destination, City or Hotel"
        }
    }

    fun initDefaults() {
        _locationState.value = LocationState.Initial
        val locale = java.util.Locale.getDefault()
        val isoCode = locale.country.lowercase().takeIf { it.isNotBlank() } ?: "us"
        val currency = countryToCurrency[isoCode] ?: "USD"
        val placeholder = getPlaceholderForCountry(isoCode)

        cachedCurrency = currency
        cachedCountry = isoCode
        _locationState.value = LocationState.Loaded(isoCode, currency, placeholder)
    }

    var userLatitude: Double? = null
    var userLongitude: Double? = null
    var isNearMeActive: Boolean = false
    var nearMeQuery: String? = null

    fun getDeviceLocation(
        fusedLocationClient: com.google.android.gms.location.FusedLocationProviderClient,
        context: android.content.Context,
        onComplete: (Boolean) -> Unit
    ) {
        if (androidx.core.content.ContextCompat.checkSelfPermission(context, android.Manifest.permission.ACCESS_FINE_LOCATION) == android.content.pm.PackageManager.PERMISSION_GRANTED ||
            androidx.core.content.ContextCompat.checkSelfPermission(context, android.Manifest.permission.ACCESS_COARSE_LOCATION) == android.content.pm.PackageManager.PERMISSION_GRANTED) {

            fusedLocationClient.lastLocation.addOnSuccessListener { location ->
                if (location != null) {
                    userLatitude = location.latitude
                    userLongitude = location.longitude

                    try {
                        val geocoder = android.location.Geocoder(context, java.util.Locale.getDefault())
                        val addresses = geocoder.getFromLocation(location.latitude, location.longitude, 1)
                        if (!addresses.isNullOrEmpty()) {
                            val address = addresses[0]
                            val locality = address.locality ?: address.subAdminArea ?: address.adminArea ?: ""
                            nearMeQuery = locality
                            onComplete(true)
                        } else {
                            onComplete(false)
                        }
                    } catch (e: Exception) {
                        onComplete(false)
                    }
                } else {
                    onComplete(false)
                }
            }.addOnFailureListener {
                onComplete(false)
            }
        } else {
            onComplete(false)
        }
    }

    fun getDistanceText(hotelLat: Double?, hotelLng: Double?): String? {
        val uLat = userLatitude ?: return null
        val uLng = userLongitude ?: return null
        if (hotelLat == null || hotelLng == null) return null
        val results = FloatArray(1)
        android.location.Location.distanceBetween(uLat, uLng, hotelLat, hotelLng, results)
        val distanceKm = results[0] / 1000f
        return String.format("%.1f km away", distanceKm)
    }

    fun searchHotels(isRetry: Boolean = false) {
        val actualQuery = if (isNearMeActive && nearMeQuery != null) nearMeQuery!! else cachedQuery
        if (actualQuery.isBlank()) return

        _uiState.value = SearchUiState.Loading(if (cachedSortBy != null) "Applying filters..." else "Searching best stays...")

        if (!isRetry && cachedSortBy == null) {
            viewModelScope.launch {
                repository.insert(
                    SearchHistory(
                        query = actualQuery,
                        country = cachedCountry,
                        currency = cachedCurrency,
                        checkIn = cachedCheckIn,
                        checkOut = cachedCheckOut,
                        adults = cachedAdults,
                        children = cachedChildren
                    )
                )
            }
        }

        viewModelScope.launch {
            try {
                val response = RetrofitClient.hotellaService.searchHotels(
                    apiKey = ApiConfig.HOTELLA_API_KEY,
                    request = SearchRequest(
                        query = actualQuery,
                        checkIn = cachedCheckIn,
                        checkOut = cachedCheckOut,
                        adults = cachedAdults,
                        children = cachedChildren,
                        currency = cachedCurrency,
                        country = cachedCountry,
                        sortBy = cachedSortBy,
                        minPrice = cachedMinPrice,
                        maxPrice = cachedMaxPrice
                    )
                )

                currentSearchId = response.searchId

                if (response.hotels.isEmpty()) {
                    _uiState.value = SearchUiState.Error("No hotels found matching your search. Try a different city or dates.")
                } else {
                    _uiState.value = SearchUiState.Success(
                        searchId = response.searchId,
                        hotels = response.hotels,
                        currentPage = response.pagination?.page ?: 1,
                        totalPages = response.pagination?.totalPages ?: 1,
                        totalItems = response.pagination?.totalItems ?: response.hotels.size,
                        hasNext = response.pagination?.hasNext ?: false,
                        unfilteredTotal = response.pagination?.unfilteredTotal,
                        sourceTotal = response.pagination?.sourceTotal,
                        totalIsComplete = response.pagination?.totalIsComplete,
                        filtersActive = response.pagination?.filtersActive,
                        isLoadingMore = false
                    )
                }
            } catch (e: Exception) {
                if (!isRetry && (e is java.net.UnknownHostException || e is java.net.ConnectException || e is java.net.SocketTimeoutException)) {
                    searchHotels(isRetry = true)
                } else {
                    _uiState.value = SearchUiState.Error("Connection error. Please verify network and try again.")
                }
            }
        }
    }

    fun loadPage(page: Int, isRetry: Boolean = false) {
        val searchId = currentSearchId ?: return
        val currentState = _uiState.value as? SearchUiState.Success
        val currentHotels = currentState?.hotels ?: emptyList()

        if (currentState != null) {
            _uiState.value = currentState.copy(isLoadingMore = true)
        }

        viewModelScope.launch {
            try {
                val response = RetrofitClient.hotellaService.getSearchPage(
                    apiKey = ApiConfig.HOTELLA_API_KEY,
                    searchId = searchId,
                    page = page
                )

                val currentPage = response.pagination?.page ?: page

                if (response.hotels.isEmpty()) {
                    if (currentState != null) {
                        _uiState.value = currentState.copy(currentPage = currentPage, isLoadingMore = false)
                    }
                } else {
                    val newHotels = (currentHotels + response.hotels).distinctBy { it.hotelRef ?: it.name }
                    _uiState.value = SearchUiState.Success(
                        searchId = searchId,
                        hotels = newHotels,
                        currentPage = currentPage,
                        totalPages = response.pagination?.totalPages ?: 1,
                        totalItems = response.pagination?.totalItems ?: newHotels.size,
                        hasNext = response.pagination?.hasNext ?: false,
                        unfilteredTotal = response.pagination?.unfilteredTotal,
                        sourceTotal = response.pagination?.sourceTotal,
                        totalIsComplete = response.pagination?.totalIsComplete,
                        filtersActive = response.pagination?.filtersActive,
                        isLoadingMore = false
                    )
                }
            } catch (e: Exception) {
                if (!isRetry && (e is java.net.UnknownHostException || e is java.net.ConnectException || e is java.net.SocketTimeoutException)) {
                    loadPage(page, isRetry = true)
                } else {
                    if (currentState != null) {
                        _uiState.value = currentState.copy(isLoadingMore = false)
                    }
                }
            }
        }
    }

    fun getHotelPrices(searchId: String, hotelRef: String) {
        _pricingUiState.value = PricingUiState.Loading
        viewModelScope.launch {
            try {
                val response = RetrofitClient.hotellaService.getHotelPrices(
                    apiKey = ApiConfig.HOTELLA_API_KEY,
                    searchId = searchId,
                    hotelRef = hotelRef
                )
                val options = response.bookingOptions ?: emptyList()
                _pricingUiState.value = PricingUiState.Success(options)
            } catch (e: retrofit2.HttpException) {
                if (e.code() == 404) {
                    _pricingUiState.value = PricingUiState.Success(emptyList())
                } else {
                    _pricingUiState.value = PricingUiState.Error("Error loading deals: ${e.message}")
                }
            } catch (e: Exception) {
                _pricingUiState.value = PricingUiState.Error("Error: ${e.message}")
            }
        }
    }

    fun resetPricingState() {
        _pricingUiState.value = PricingUiState.Initial
    }
}
