package com.example

import android.annotation.SuppressLint
import android.content.Context
import android.os.Bundle
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.Popup
import coil.compose.AsyncImage
import com.example.data.SavedHotel
import com.example.network.models.Hotel
import com.example.ui.theme.*
import com.example.viewmodel.LocationState
import com.example.viewmodel.PricingUiState
import com.example.viewmodel.SearchUiState
import com.example.viewmodel.SearchViewModel
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    private val viewModel: SearchViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                Scaffold(
                    modifier = Modifier.fillMaxSize()
                ) { innerPadding ->
                    StarlightMainScreen(
                        modifier = Modifier.padding(innerPadding),
                        viewModel = viewModel
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class, com.google.accompanist.permissions.ExperimentalPermissionsApi::class)
@Composable
fun StarlightMainScreen(modifier: Modifier = Modifier, viewModel: SearchViewModel) {
    var selectedNavIndex by remember { mutableIntStateOf(0) }

    val wishlistState by viewModel.wishlist.collectAsState()

    Scaffold(
        bottomBar = {
            StarlightBottomNavigationBar(
                selectedIndex = selectedNavIndex,
                onTabSelected = { selectedNavIndex = it },
                wishlistCount = wishlistState.size
            )
        },
        containerColor = BackgroundLight
    ) { paddingValues ->
        Box(
            modifier = modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            when (selectedNavIndex) {
                0 -> SearchTabContent(viewModel = viewModel)
                1 -> BookingsTabContent()
                2 -> WishlistTabContent(viewModel = viewModel)
                3 -> ProfileTabContent(viewModel = viewModel)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class, com.google.accompanist.permissions.ExperimentalPermissionsApi::class)
@Composable
fun SearchTabContent(viewModel: SearchViewModel) {
    val uiState by viewModel.uiState.collectAsState()
    val pricingState by viewModel.pricingUiState.collectAsState()
    val locationState by viewModel.locationState.collectAsState()
    val wishlist by viewModel.wishlist.collectAsState()

    val context = LocalContext.current
    val fusedLocationClient = remember { com.google.android.gms.location.LocationServices.getFusedLocationProviderClient(context) }
    val locationPermissionsState = com.google.accompanist.permissions.rememberMultiplePermissionsState(
        listOf(
            android.Manifest.permission.ACCESS_COARSE_LOCATION,
            android.Manifest.permission.ACCESS_FINE_LOCATION
        )
    )

    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var showBottomSheet by remember { mutableStateOf(false) }
    var showHistoryScreen by remember { mutableStateOf(false) }

    LaunchedEffect(pricingState) {
        showBottomSheet = pricingState is PricingUiState.Success || pricingState is PricingUiState.Error || pricingState is PricingUiState.Loading
    }

    val placeholder = if (locationState is LocationState.Loaded) {
        (locationState as LocationState.Loaded).placeholder
    } else "Enter city, hotel or area"

    if (showHistoryScreen) {
        HistoryScreen(
            viewModel = viewModel,
            onClose = { showHistoryScreen = false },
            onSelectHistory = { history ->
                viewModel.cachedQuery = history.query
                viewModel.cachedCountry = history.country
                viewModel.cachedCurrency = history.currency
                viewModel.cachedCheckIn = history.checkIn
                viewModel.cachedCheckOut = history.checkOut
                viewModel.cachedAdults = history.adults
                viewModel.cachedChildren = history.children
                showHistoryScreen = false
                viewModel.searchHotels()
            }
        )
        return
    }

    val listState = rememberLazyListState()
    val coroutineScope = rememberCoroutineScope()

    LazyColumn(
        state = listState,
        modifier = Modifier
            .fillMaxSize()
            .background(BackgroundLight),
        contentPadding = PaddingValues(bottom = 24.dp)
    ) {
        // Top Hero Header with Menu & Notifications
        item {
            HeroHeaderSection(
                onMenuClick = { showHistoryScreen = true },
                onNotificationClick = { }
            )
        }

        // Category Tabs (Hotels, Resorts, Villas, Apartments)
        item {
            CategoryTabsSection(
                selectedCategory = viewModel.selectedCategory,
                onCategorySelected = { category ->
                    viewModel.selectedCategory = category
                    if (viewModel.cachedQuery.isNotBlank()) {
                        viewModel.searchHotels()
                    }
                }
            )
        }

        // Floating Search Card
        item {
            FloatingSearchCard(
                viewModel = viewModel,
                isLoading = uiState is SearchUiState.Loading,
                placeholder = placeholder,
                fusedLocationClient = fusedLocationClient,
                locationPermissionsState = locationPermissionsState,
                onSearchTriggered = {
                    coroutineScope.launch {
                        listState.animateScrollToItem(4)
                    }
                }
            )
        }

        // Popular Destinations
        item {
            PopularDestinationsSection(
                onDestinationClick = { destination ->
                    viewModel.cachedQuery = destination
                    viewModel.isNearMeActive = false
                    viewModel.searchHotels()
                    coroutineScope.launch {
                        listState.animateScrollToItem(4)
                    }
                }
            )
        }

        // Real API Search Results or Featured Top Picks
        when (val state = uiState) {
            is SearchUiState.Loading -> {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(200.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            CircularProgressIndicator(color = PrimaryPurple)
                            Spacer(modifier = Modifier.height(16.dp))
                            Text(text = state.message, color = PrimaryPurple, fontWeight = FontWeight.Medium)
                        }
                    }
                }
            }
            is SearchUiState.Success -> {
                item {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 20.dp, vertical = 12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "${state.totalItems} Stays Found in ${viewModel.cachedQuery}",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                    }
                }

                items(state.hotels) { hotel ->
                    val isSaved = wishlist.any { it.hotelRef == (hotel.hotelRef ?: hotel.name) }
                    val distanceText = viewModel.getDistanceText(hotel.map?.latitude, hotel.map?.longitude)
                    RedesignedHotelCard(
                        hotel = hotel,
                        distanceText = distanceText,
                        isSaved = isSaved,
                        onFavoriteClick = { viewModel.toggleWishlist(hotel) },
                        onViewDeal = {
                            if (hotel.hotelRef != null) {
                                viewModel.getHotelPrices(state.searchId, hotel.hotelRef)
                            }
                        }
                    )
                }

                if (state.hasNext) {
                    item {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 16.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Button(
                                onClick = { if (!state.isLoadingMore) viewModel.loadPage(state.currentPage + 1) },
                                enabled = !state.isLoadingMore,
                                colors = ButtonDefaults.buttonColors(containerColor = PrimaryPurple),
                                shape = RoundedCornerShape(50)
                            ) {
                                Text(if (state.isLoadingMore) "Loading More..." else "Load More Hotels")
                            }
                        }
                    }
                }
            }
            is SearchUiState.Error -> {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(32.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                imageVector = Icons.Default.SearchOff,
                                contentDescription = "Error",
                                tint = PrimaryPurple.copy(alpha = 0.5f),
                                modifier = Modifier.size(56.dp)
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = state.message,
                                fontSize = 15.sp,
                                color = TextSecondary,
                                textAlign = TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Button(
                                onClick = { viewModel.searchHotels(isRetry = true) },
                                colors = ButtonDefaults.buttonColors(containerColor = PrimaryPurple)
                            ) {
                                Text("Retry Search")
                            }
                        }
                    }
                }
            }
            else -> {
                // Initial State: Show Featured Top Picks
                item {
                    TopPicksSection(
                        wishlist = wishlist,
                        onFavoriteClick = { hotel -> viewModel.toggleWishlist(hotel) },
                        onViewDeal = { hotelName ->
                            viewModel.cachedQuery = hotelName
                            viewModel.searchHotels()
                        }
                    )
                }
            }
        }
    }

    if (showBottomSheet) {
        ModalBottomSheet(
            onDismissRequest = {
                showBottomSheet = false
                viewModel.resetPricingState()
            },
            sheetState = sheetState
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {
                when (val pState = pricingState) {
                    is PricingUiState.Loading -> {
                        Box(modifier = Modifier.fillMaxWidth().height(150.dp), contentAlignment = Alignment.Center) {
                            CircularProgressIndicator(color = PrimaryPurple)
                        }
                    }
                    is PricingUiState.Error -> {
                        Box(modifier = Modifier.fillMaxWidth().height(150.dp), contentAlignment = Alignment.Center) {
                            Text(text = pState.message, color = MaterialTheme.colorScheme.error)
                        }
                    }
                    is PricingUiState.Success -> {
                        if (pState.bookingOptions.isEmpty()) {
                            Box(modifier = Modifier.fillMaxWidth().height(150.dp), contentAlignment = Alignment.Center) {
                                Text(text = "No direct provider prices available for these dates.", color = TextSecondary)
                            }
                        } else {
                            LazyColumn(
                                verticalArrangement = Arrangement.spacedBy(12.dp),
                                modifier = Modifier.padding(bottom = 24.dp)
                            ) {
                                item {
                                    Text(
                                        text = "Available Booking Deals",
                                        fontSize = 20.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = TextPrimary
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                }
                                items(pState.bookingOptions) { option ->
                                    val uriHandler = LocalUriHandler.current
                                    Card(
                                        onClick = { uriHandler.openUri(option.bookingUrl) },
                                        shape = RoundedCornerShape(16.dp),
                                        colors = CardDefaults.cardColors(containerColor = Color.White),
                                        border = androidx.compose.foundation.BorderStroke(1.dp, BorderColor),
                                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                                    ) {
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(16.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                if (option.providerLogoUrl != null) {
                                                    AsyncImage(
                                                        model = option.providerLogoUrl,
                                                        contentDescription = option.provider,
                                                        modifier = Modifier.size(28.dp)
                                                    )
                                                    Spacer(modifier = Modifier.width(12.dp))
                                                }
                                                Text(
                                                    text = option.provider,
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 16.sp,
                                                    color = TextPrimary
                                                )
                                            }
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Column(horizontalAlignment = Alignment.End) {
                                                    Text(
                                                        text = option.stayTotalDisplay ?: option.nightlyPriceDisplay ?: "Available",
                                                        fontWeight = FontWeight.Bold,
                                                        fontSize = 16.sp,
                                                        color = PrimaryPurple
                                                    )
                                                    if (option.stayTotalDisplay != null) {
                                                        Text(text = "total stay", color = TextSecondary, fontSize = 11.sp)
                                                    }
                                                }
                                                Spacer(modifier = Modifier.width(12.dp))
                                                Icon(
                                                    Icons.AutoMirrored.Filled.ArrowForward,
                                                    contentDescription = "View Deal",
                                                    tint = PrimaryPurple,
                                                    modifier = Modifier.size(20.dp)
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    else -> {}
                }
            }
        }
    }
}

@Composable
fun HeroHeaderSection(onMenuClick: () -> Unit, onNotificationClick: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(240.dp)
            .background(
                Brush.verticalGradient(
                    colors = listOf(HeroGradientStart, HeroGradientEnd)
                )
            )
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            drawCircle(
                color = Color.White.copy(alpha = 0.04f),
                radius = 180.dp.toPx(),
                center = androidx.compose.ui.geometry.Offset(size.width * 0.8f, 20f)
            )
            drawCircle(
                color = Color.White.copy(alpha = 0.03f),
                radius = 120.dp.toPx(),
                center = androidx.compose.ui.geometry.Offset(size.width * 0.2f, size.height)
            )
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 20.dp, vertical = 16.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Top Bar: Hamburger menu & Notification bell
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    shape = CircleShape,
                    color = Color.White.copy(alpha = 0.15f),
                    modifier = Modifier
                        .size(42.dp)
                        .clickable { onMenuClick() }
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Default.Menu,
                            contentDescription = "Menu / History",
                            tint = Color.White,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                }

                Surface(
                    shape = CircleShape,
                    color = Color.White.copy(alpha = 0.15f),
                    modifier = Modifier
                        .size(42.dp)
                        .clickable { onNotificationClick() }
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Default.Notifications,
                            contentDescription = "Notifications",
                            tint = Color.White,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                }
            }

            // Headline Text
            Column(modifier = Modifier.padding(bottom = 12.dp)) {
                Text(
                    text = "Find Your",
                    fontSize = 28.sp,
                    fontWeight = FontWeight.Light,
                    color = Color.White
                )
                Text(
                    text = "Perfect Stay",
                    fontSize = 34.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = Color.White
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Handpicked hotels at the best prices",
                    fontSize = 14.sp,
                    color = Color.White.copy(alpha = 0.8f)
                )
            }
        }
    }
}

@Composable
fun CategoryTabsSection(selectedCategory: String, onCategorySelected: (String) -> Unit) {
    val categories = listOf(
        CategoryItem("Hotels", Icons.Default.Hotel),
        CategoryItem("Resorts", Icons.Default.BeachAccess),
        CategoryItem("Villas", Icons.Default.Villa),
        CategoryItem("Apartments", Icons.Default.Apartment)
    )

    LazyRow(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        items(categories) { category ->
            val isSelected = category.name.equals(selectedCategory, ignoreCase = true)
            Surface(
                onClick = { onCategorySelected(category.name) },
                shape = RoundedCornerShape(50),
                color = if (isSelected) Color.White else Color.White.copy(alpha = 0.6f),
                border = if (isSelected) androidx.compose.foundation.BorderStroke(1.5.dp, PrimaryPurple) else androidx.compose.foundation.BorderStroke(1.dp, BorderColor),
                shadowElevation = if (isSelected) 3.dp else 0.dp
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = category.icon,
                        contentDescription = category.name,
                        tint = if (isSelected) PrimaryPurple else PillUnselectedText,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = category.name,
                        fontSize = 14.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                        color = if (isSelected) PrimaryPurple else PillUnselectedText
                    )
                }
            }
        }
    }
}

data class CategoryItem(val name: String, val icon: ImageVector)

@OptIn(ExperimentalMaterial3Api::class, com.google.accompanist.permissions.ExperimentalPermissionsApi::class)
@Composable
fun FloatingSearchCard(
    viewModel: SearchViewModel,
    isLoading: Boolean,
    placeholder: String,
    fusedLocationClient: com.google.android.gms.location.FusedLocationProviderClient,
    locationPermissionsState: com.google.accompanist.permissions.MultiplePermissionsState,
    onSearchTriggered: () -> Unit
) {
    var query by remember { mutableStateOf(viewModel.cachedQuery) }
    var checkIn by remember { mutableStateOf(viewModel.cachedCheckIn) }
    var checkOut by remember { mutableStateOf(viewModel.cachedCheckOut) }
    var adults by remember { mutableStateOf(viewModel.cachedAdults) }
    var children by remember { mutableStateOf(viewModel.cachedChildren) }
    var rooms by remember { mutableStateOf(viewModel.cachedRooms) }
    var isLocating by remember { mutableStateOf(false) }

    var showDatePicker by remember { mutableStateOf(false) }
    var showGuestDialog by remember { mutableStateOf(false) }
    var showSortFilterDialog by remember { mutableStateOf(false) }

    val dateRangePickerState = rememberDateRangePickerState()
    val focusManager = LocalFocusManager.current
    val contextForLocation = LocalContext.current

    Card(
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 6.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, BorderColor),
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
        Column(
            modifier = Modifier.padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // "Where to?" input
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Where to?",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )

                    Icon(
                        imageVector = Icons.Default.FilterList,
                        contentDescription = "Filters",
                        tint = PrimaryPurple,
                        modifier = Modifier
                            .size(22.dp)
                            .clickable { showSortFilterDialog = true }
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))

                OutlinedTextField(
                    value = if (isLocating) "Getting location..." else if (viewModel.isNearMeActive) "Near me" else query,
                    onValueChange = {
                        viewModel.isNearMeActive = false
                        query = it
                        viewModel.cachedQuery = it
                    },
                    placeholder = { Text(placeholder, fontSize = 14.sp, color = TextSecondary) },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                    keyboardActions = KeyboardActions(onSearch = {
                        focusManager.clearFocus()
                        if (query.isNotBlank() && !isLocating) {
                            viewModel.searchHotels()
                            onSearchTriggered()
                        }
                    }),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedBorderColor = PrimaryPurple,
                        unfocusedBorderColor = BorderColor
                    ),
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.LocationOn,
                            contentDescription = "Location",
                            tint = PrimaryPurple
                        )
                    },
                    trailingIcon = {
                        IconButton(
                            onClick = {
                                if (locationPermissionsState.allPermissionsGranted) {
                                    isLocating = true
                                    viewModel.getDeviceLocation(fusedLocationClient, contextForLocation) { success ->
                                        isLocating = false
                                        if (success) {
                                            viewModel.isNearMeActive = true
                                            query = "Near me"
                                            viewModel.cachedQuery = "Near me"
                                        }
                                    }
                                } else {
                                    locationPermissionsState.launchMultiplePermissionRequest()
                                }
                            }
                        ) {
                            if (isLocating) {
                                CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp, color = PrimaryPurple)
                            } else {
                                Icon(
                                    imageVector = Icons.Default.MyLocation,
                                    contentDescription = "Near me",
                                    tint = PrimaryPurple
                                )
                            }
                        }
                    }
                )
            }

            // Check-in & Check-out Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Check-in
                Surface(
                    onClick = { showDatePicker = true },
                    shape = RoundedCornerShape(16.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, BorderColor),
                    color = BackgroundLight,
                    modifier = Modifier
                        .weight(1f)
                        .height(60.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 12.dp)
                    ) {
                        Icon(Icons.Default.DateRange, contentDescription = "Check-in", tint = PrimaryPurple, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text("Check-in", fontSize = 11.sp, color = TextSecondary)
                            Text(checkIn, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = TextPrimary, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    }
                }

                // Check-out
                Surface(
                    onClick = { showDatePicker = true },
                    shape = RoundedCornerShape(16.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, BorderColor),
                    color = BackgroundLight,
                    modifier = Modifier
                        .weight(1f)
                        .height(60.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 12.dp)
                    ) {
                        Icon(Icons.Default.DateRange, contentDescription = "Check-out", tint = PrimaryPurple, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text("Check-out", fontSize = 11.sp, color = TextSecondary)
                            Text(checkOut, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = TextPrimary, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    }
                }
            }

            // Guests & Rooms Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Guests
                Surface(
                    onClick = { showGuestDialog = true },
                    shape = RoundedCornerShape(16.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, BorderColor),
                    color = BackgroundLight,
                    modifier = Modifier
                        .weight(1f)
                        .height(60.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 12.dp)
                    ) {
                        Icon(Icons.Default.Person, contentDescription = "Guests", tint = PrimaryPurple, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text("Guests", fontSize = 11.sp, color = TextSecondary)
                            Text("$adults Adults", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                        }
                    }
                }

                // Rooms
                Surface(
                    onClick = { showGuestDialog = true },
                    shape = RoundedCornerShape(16.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, BorderColor),
                    color = BackgroundLight,
                    modifier = Modifier
                        .weight(1f)
                        .height(60.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 12.dp)
                    ) {
                        Icon(Icons.Default.MeetingRoom, contentDescription = "Rooms", tint = PrimaryPurple, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text("Rooms", fontSize = 11.sp, color = TextSecondary)
                            Text("$rooms Room", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                        }
                    }
                }
            }

            // Search Hotels Button
            Button(
                onClick = {
                    focusManager.clearFocus()
                    if (query.isNotBlank()) {
                        viewModel.searchHotels()
                        onSearchTriggered()
                    }
                },
                enabled = !isLoading && (query.isNotBlank() || viewModel.isNearMeActive),
                colors = ButtonDefaults.buttonColors(containerColor = PrimaryPurple),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp),
                shape = RoundedCornerShape(50)
            ) {
                Text("Search Hotels", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.White)
            }
        }
    }

    if (showDatePicker) {
        DatePickerDialog(
            onDismissRequest = { showDatePicker = false },
            confirmButton = {
                TextButton(onClick = {
                    showDatePicker = false
                    val startMillis = dateRangePickerState.selectedStartDateMillis
                    val endMillis = dateRangePickerState.selectedEndDateMillis
                    if (startMillis != null && endMillis != null) {
                        val formatter = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.getDefault())
                        checkIn = formatter.format(java.util.Date(startMillis))
                        viewModel.cachedCheckIn = checkIn
                        checkOut = formatter.format(java.util.Date(endMillis))
                        viewModel.cachedCheckOut = checkOut
                    }
                }) {
                    Text("OK", color = PrimaryPurple, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDatePicker = false }) {
                    Text("Cancel", color = TextSecondary)
                }
            }
        ) {
            DateRangePicker(
                state = dateRangePickerState,
                title = { Text(text = "Select Stay Dates", modifier = Modifier.padding(16.dp), fontWeight = FontWeight.Bold) },
                showModeToggle = false,
                colors = DatePickerDefaults.colors(
                    selectedDayContainerColor = PrimaryPurple,
                    todayDateBorderColor = PrimaryPurple,
                    todayContentColor = PrimaryPurple
                )
            )
        }
    }

    if (showGuestDialog) {
        Dialog(onDismissRequest = { showGuestDialog = false }) {
            Surface(shape = RoundedCornerShape(20.dp), color = Color.White) {
                Column(modifier = Modifier.padding(24.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                    Text("Guests & Rooms", fontWeight = FontWeight.Bold, fontSize = 20.sp, color = TextPrimary)

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("Adults", fontSize = 16.sp, color = TextPrimary)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(onClick = { if (adults > 1) { adults--; viewModel.cachedAdults = adults } }) {
                                Icon(Icons.Default.Remove, contentDescription = "Less", tint = PrimaryPurple)
                            }
                            Text(adults.toString(), fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 8.dp))
                            IconButton(onClick = { adults++; viewModel.cachedAdults = adults }) {
                                Icon(Icons.Default.Add, contentDescription = "More", tint = PrimaryPurple)
                            }
                        }
                    }

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("Children", fontSize = 16.sp, color = TextPrimary)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(onClick = { if (children > 0) { children--; viewModel.cachedChildren = children } }) {
                                Icon(Icons.Default.Remove, contentDescription = "Less", tint = PrimaryPurple)
                            }
                            Text(children.toString(), fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 8.dp))
                            IconButton(onClick = { children++; viewModel.cachedChildren = children }) {
                                Icon(Icons.Default.Add, contentDescription = "More", tint = PrimaryPurple)
                            }
                        }
                    }

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("Rooms", fontSize = 16.sp, color = TextPrimary)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(onClick = { if (rooms > 1) { rooms--; viewModel.cachedRooms = rooms } }) {
                                Icon(Icons.Default.Remove, contentDescription = "Less", tint = PrimaryPurple)
                            }
                            Text(rooms.toString(), fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 8.dp))
                            IconButton(onClick = { rooms++; viewModel.cachedRooms = rooms }) {
                                Icon(Icons.Default.Add, contentDescription = "More", tint = PrimaryPurple)
                            }
                        }
                    }

                    Button(
                        onClick = { showGuestDialog = false },
                        modifier = Modifier.fillMaxWidth().height(48.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = PrimaryPurple),
                        shape = RoundedCornerShape(50)
                    ) {
                        Text("Done", color = Color.White, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }

    if (showSortFilterDialog) {
        val sortOptions = mapOf(
            "Best Value" to "value",
            "Price (Lowest)" to "price-asc",
            "Price (Highest)" to "price-desc",
            "Guest Rating" to "rating",
            "Most Reviews" to "reviews"
        )
        SortFilterDialog(
            sortOptions = sortOptions,
            currentSort = viewModel.cachedSortBy,
            currentMinPrice = viewModel.cachedMinPrice,
            currentMaxPrice = viewModel.cachedMaxPrice,
            onApply = { sortValue, minPrice, maxPrice ->
                viewModel.cachedSortBy = sortValue
                viewModel.cachedMinPrice = minPrice
                viewModel.cachedMaxPrice = maxPrice
                showSortFilterDialog = false
                if (query.isNotBlank()) {
                    viewModel.searchHotels()
                    onSearchTriggered()
                }
            },
            onDismiss = { showSortFilterDialog = false }
        )
    }
}

@Composable
fun PopularDestinationsSection(onDestinationClick: (String) -> Unit) {
    val destinations = listOf(
        DestinationItem("Dubai", "1,250+ Hotels", "https://images.unsplash.com/photo-1512453979798-5ea266f8880c?w=600&q=80"),
        DestinationItem("Bali", "890+ Hotels", "https://images.unsplash.com/photo-1537996194471-e657df975ab4?w=600&q=80"),
        DestinationItem("Istanbul", "760+ Hotels", "https://images.unsplash.com/photo-1524231757912-21f4fe3a7200?w=600&q=80"),
        DestinationItem("Maldives", "620+ Hotels", "https://images.unsplash.com/photo-1514282401047-d79a71a590e8?w=600&q=80")
    )

    Column(modifier = Modifier.padding(vertical = 12.dp)) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Popular Destinations", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
            Text(
                "View all",
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
                color = PrimaryPurple,
                modifier = Modifier.clickable { onDestinationClick("Dubai") }
            )
        }

        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            items(destinations) { dest ->
                Card(
                    onClick = { onDestinationClick(dest.name) },
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
                    modifier = Modifier.width(140.dp)
                ) {
                    Column {
                        Box(modifier = Modifier.height(110.dp).fillMaxWidth()) {
                            AsyncImage(
                                model = dest.imageUrl,
                                contentDescription = dest.name,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                        }
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(dest.name, fontWeight = FontWeight.Bold, fontSize = 15.sp, color = TextPrimary)
                            Text(dest.count, fontSize = 12.sp, color = TextSecondary)
                        }
                    }
                }
            }
        }
    }
}

data class DestinationItem(val name: String, val count: String, val imageUrl: String)

@Composable
fun TopPicksSection(
    wishlist: List<SavedHotel>,
    onFavoriteClick: (Hotel) -> Unit,
    onViewDeal: (String) -> Unit
) {
    val topPicks = listOf(
        Hotel(
            name = "Sea View Resort",
            hotelRef = "sea_view_resort_maldives",
            googleEntityKey = null,
            rating = 4.8,
            reviewCount = 342,
            price = 180.0,
            currency = "USD",
            address = "Maldives",
            imageUrl = "https://images.unsplash.com/photo-1540555700478-4be289fbecef?w=600&q=80",
            viewPricesUrl = null,
            pricesApiUrl = null,
            nightlyPriceDisplay = "$180/night"
        ),
        Hotel(
            name = "Downtown Grand Hotel",
            hotelRef = "downtown_grand_dubai",
            googleEntityKey = null,
            rating = 4.6,
            reviewCount = 198,
            price = 150.0,
            currency = "USD",
            address = "Dubai, UAE",
            imageUrl = "https://images.unsplash.com/photo-1566073771259-6a8506099945?w=600&q=80",
            viewPricesUrl = null,
            pricesApiUrl = null,
            nightlyPriceDisplay = "$150/night"
        ),
        Hotel(
            name = "Royal Palace Hotel",
            hotelRef = "royal_palace_dubai",
            googleEntityKey = null,
            rating = 4.7,
            reviewCount = 256,
            price = 200.0,
            currency = "USD",
            address = "Business Bay, Dubai",
            imageUrl = "https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?w=600&q=80",
            viewPricesUrl = null,
            pricesApiUrl = null,
            nightlyPriceDisplay = "$200/night"
        )
    )

    Column(modifier = Modifier.padding(vertical = 12.dp)) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Top Picks for You", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
            Text(
                "View all",
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
                color = PrimaryPurple,
                modifier = Modifier.clickable { onViewDeal("Dubai") }
            )
        }

        topPicks.forEach { hotel ->
            val isSaved = wishlist.any { it.hotelRef == (hotel.hotelRef ?: hotel.name) }
            RedesignedHotelCard(
                hotel = hotel,
                distanceText = null,
                isSaved = isSaved,
                onFavoriteClick = { onFavoriteClick(hotel) },
                onViewDeal = { onViewDeal(hotel.address ?: hotel.name) }
            )
        }
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun RedesignedHotelCard(
    hotel: Hotel,
    distanceText: String? = null,
    isSaved: Boolean = false,
    onFavoriteClick: () -> Unit,
    onViewDeal: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, BorderColor),
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
        Column {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp)
            ) {
                AsyncImage(
                    model = hotel.imageUrl ?: "https://images.unsplash.com/photo-1551882547-ff40c63fe5fa?w=600&q=80",
                    contentDescription = hotel.name,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )

                // Top-Left Badge
                if (hotel.rating != null && hotel.rating >= 4.5) {
                    Surface(
                        shape = RoundedCornerShape(50),
                        color = AccentOrange,
                        modifier = Modifier
                            .padding(12.dp)
                            .align(Alignment.TopStart)
                    ) {
                        Text(
                            text = "GUEST FAVORITE",
                            color = Color.White,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                        )
                    }
                }

                // Top-Right Wishlist Heart Icon
                Surface(
                    shape = CircleShape,
                    color = Color.White,
                    shadowElevation = 4.dp,
                    modifier = Modifier
                        .padding(12.dp)
                        .align(Alignment.TopEnd)
                        .size(36.dp)
                        .clickable { onFavoriteClick() }
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = if (isSaved) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                            contentDescription = "Favorite",
                            tint = if (isSaved) Color.Red else TextSecondary,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }

            // Card Body Info
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Top
                ) {
                    Text(
                        text = hotel.name,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )

                    Spacer(modifier = Modifier.width(8.dp))

                    if (hotel.rating != null) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Star, contentDescription = "Rating", tint = StarYellow, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(3.dp))
                            Text(
                                text = "${hotel.rating} (${hotel.reviewCount ?: 0})",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                val locationText = buildString {
                    append(hotel.address ?: "Location available")
                    if (distanceText != null) append(" • $distanceText")
                }
                Text(
                    text = locationText,
                    color = TextSecondary,
                    fontSize = 13.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )

                Spacer(modifier = Modifier.height(14.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = hotel.nightlyPriceDisplay ?: hotel.price?.let { "$${it.toInt()}" } ?: "Best Deal",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = PrimaryPurple
                        )
                        Text(text = "per night", color = TextSecondary, fontSize = 12.sp)
                    }

                    Button(
                        onClick = onViewDeal,
                        colors = ButtonDefaults.buttonColors(containerColor = PrimaryPurple),
                        shape = RoundedCornerShape(50),
                        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 10.dp)
                    ) {
                        Text("View Deal", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun BookingsTabContent() {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            border = androidx.compose.foundation.BorderStroke(1.dp, BorderColor),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(28.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(
                    imageVector = Icons.Default.HotelClass,
                    contentDescription = "Bookings",
                    tint = PrimaryPurple,
                    modifier = Modifier.size(56.dp)
                )
                Spacer(modifier = Modifier.height(16.dp))
                Text("Hotel Search App", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    "This app specializes in searching hotels and comparing prices across top providers. When you choose a deal, booking is handled directly with the provider.",
                    fontSize = 14.sp,
                    color = TextSecondary,
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}

@Composable
fun WishlistTabContent(viewModel: SearchViewModel) {
    val wishlist by viewModel.wishlist.collectAsState()

    if (wishlist.isEmpty()) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(32.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(
                    imageVector = Icons.Default.FavoriteBorder,
                    contentDescription = "Wishlist",
                    tint = PrimaryPurple.copy(alpha = 0.4f),
                    modifier = Modifier.size(64.dp)
                )
                Spacer(modifier = Modifier.height(16.dp))
                Text("Your Wishlist is Empty", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                Spacer(modifier = Modifier.height(8.dp))
                Text("Save your favorite hotels here to easily compare them later.", color = TextSecondary, fontSize = 14.sp, textAlign = TextAlign.Center)
            }
        }
    } else {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Text(
                    text = "Saved Stays (${wishlist.size})",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary,
                    modifier = Modifier.padding(bottom = 8.dp)
                )
            }

            items(wishlist) { saved ->
                val hotel = Hotel(
                    name = saved.name,
                    hotelRef = saved.hotelRef,
                    googleEntityKey = null,
                    rating = saved.rating,
                    reviewCount = saved.reviewCount,
                    price = null,
                    currency = saved.currency,
                    address = saved.address,
                    imageUrl = saved.imageUrl,
                    viewPricesUrl = null,
                    pricesApiUrl = null,
                    nightlyPriceDisplay = saved.nightlyPriceDisplay
                )
                RedesignedHotelCard(
                    hotel = hotel,
                    isSaved = true,
                    onFavoriteClick = { viewModel.toggleWishlist(hotel) },
                    onViewDeal = {
                        viewModel.cachedQuery = hotel.name
                        viewModel.searchHotels()
                    }
                )
            }
        }
    }
}

@Composable
fun ProfileTabContent(viewModel: SearchViewModel) {
    var showCurrencyDropdown by remember { mutableStateOf(false) }
    var showCountryDropdown by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(
                    shape = CircleShape,
                    color = PrimaryPurpleLight,
                    modifier = Modifier.size(60.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.Person, contentDescription = "Profile", tint = PrimaryPurple, modifier = Modifier.size(32.dp))
                    }
                }
                Spacer(modifier = Modifier.width(16.dp))
                Column {
                    Text("Starlight Traveler", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                    Text("Welcome to Starlight Hotel Search", fontSize = 13.sp, color = TextSecondary)
                }
            }
        }

        item {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = androidx.compose.foundation.BorderStroke(1.dp, BorderColor)
            ) {
                Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                    Text("Search Preferences", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = TextPrimary)

                    // Currency Selection
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { showCurrencyDropdown = true }
                            .padding(vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.AttachMoney, contentDescription = "Currency", tint = PrimaryPurple)
                            Spacer(modifier = Modifier.width(12.dp))
                            Text("Currency", fontSize = 15.sp, color = TextPrimary)
                        }
                        Text(viewModel.cachedCurrency, fontWeight = FontWeight.Bold, color = PrimaryPurple, fontSize = 15.sp)
                    }

                    HorizontalDivider(color = BorderColor)

                    // Country Selection
                    val countryName = viewModel.countries[viewModel.cachedCountry.lowercase()] ?: viewModel.cachedCountry
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { showCountryDropdown = true }
                            .padding(vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Public, contentDescription = "Country", tint = PrimaryPurple)
                            Spacer(modifier = Modifier.width(12.dp))
                            Text("Country / Region", fontSize = 15.sp, color = TextPrimary)
                        }
                        Text(countryName, fontWeight = FontWeight.Bold, color = PrimaryPurple, fontSize = 15.sp)
                    }
                }
            }
        }

        item {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = androidx.compose.foundation.BorderStroke(1.dp, BorderColor)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { viewModel.clearHistory() }
                            .padding(vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Delete, contentDescription = "Clear History", tint = MaterialTheme.colorScheme.error)
                            Spacer(modifier = Modifier.width(12.dp))
                            Text("Clear Search History", fontSize = 15.sp, color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }

    if (showCurrencyDropdown) {
        SearchableDropdownDialog(
            title = "Select Currency",
            items = viewModel.currencies,
            onItemSelected = { curr ->
                viewModel.cachedCurrency = curr
                showCurrencyDropdown = false
            },
            onDismiss = { showCurrencyDropdown = false }
        )
    }

    if (showCountryDropdown) {
        SearchableDropdownDialog(
            title = "Select Country",
            items = viewModel.countries.values.toList().sorted(),
            onItemSelected = { name ->
                val code = viewModel.countries.entries.firstOrNull { it.value == name }?.key ?: name
                viewModel.cachedCountry = code
                val mappedCurrency = viewModel.countryToCurrency[code.lowercase()]
                if (mappedCurrency != null) {
                    viewModel.cachedCurrency = mappedCurrency
                }
                showCountryDropdown = false
            },
            onDismiss = { showCountryDropdown = false }
        )
    }
}

@Composable
fun StarlightBottomNavigationBar(
    selectedIndex: Int,
    onTabSelected: (Int) -> Unit,
    wishlistCount: Int
) {
    NavigationBar(
        containerColor = Color.White,
        tonalElevation = 8.dp
    ) {
        NavigationBarItem(
            selected = selectedIndex == 0,
            onClick = { onTabSelected(0) },
            icon = { Icon(Icons.Default.Search, contentDescription = "Search") },
            label = { Text("Search", fontSize = 12.sp, fontWeight = if (selectedIndex == 0) FontWeight.Bold else FontWeight.Normal) },
            colors = NavigationBarItemDefaults.colors(selectedIconColor = PrimaryPurple, selectedTextColor = PrimaryPurple, indicatorColor = PrimaryPurpleLight)
        )

        NavigationBarItem(
            selected = selectedIndex == 1,
            onClick = { onTabSelected(1) },
            icon = { Icon(Icons.Default.DateRange, contentDescription = "Bookings") },
            label = { Text("Bookings", fontSize = 12.sp, fontWeight = if (selectedIndex == 1) FontWeight.Bold else FontWeight.Normal) },
            colors = NavigationBarItemDefaults.colors(selectedIconColor = PrimaryPurple, selectedTextColor = PrimaryPurple, indicatorColor = PrimaryPurpleLight)
        )

        NavigationBarItem(
            selected = selectedIndex == 2,
            onClick = { onTabSelected(2) },
            icon = {
                BadgedBox(
                    badge = {
                        if (wishlistCount > 0) {
                            Badge(containerColor = PrimaryPurple) { Text(wishlistCount.toString(), color = Color.White) }
                        }
                    }
                ) {
                    Icon(
                        imageVector = if (selectedIndex == 2) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                        contentDescription = "Wishlist"
                    )
                }
            },
            label = { Text("Wishlist", fontSize = 12.sp, fontWeight = if (selectedIndex == 2) FontWeight.Bold else FontWeight.Normal) },
            colors = NavigationBarItemDefaults.colors(selectedIconColor = PrimaryPurple, selectedTextColor = PrimaryPurple, indicatorColor = PrimaryPurpleLight)
        )

        NavigationBarItem(
            selected = selectedIndex == 3,
            onClick = { onTabSelected(3) },
            icon = { Icon(Icons.Default.Person, contentDescription = "Profile") },
            label = { Text("Profile", fontSize = 12.sp, fontWeight = if (selectedIndex == 3) FontWeight.Bold else FontWeight.Normal) },
            colors = NavigationBarItemDefaults.colors(selectedIconColor = PrimaryPurple, selectedTextColor = PrimaryPurple, indicatorColor = PrimaryPurpleLight)
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HistoryScreen(
    viewModel: SearchViewModel,
    onClose: () -> Unit,
    onSelectHistory: (com.example.data.SearchHistory) -> Unit
) {
    val historyList by viewModel.recentHistory.collectAsState()

    Scaffold(
        containerColor = Color.White,
        topBar = {
            TopAppBar(
                title = { Text("Recent Searches", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onClose) {
                        Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = { viewModel.clearHistory() }) {
                        Icon(imageVector = Icons.Default.Delete, contentDescription = "Clear History", tint = MaterialTheme.colorScheme.error)
                    }
                }
            )
        }
    ) { paddingValues ->
        if (historyList.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues),
                contentAlignment = Alignment.Center
            ) {
                Text("No recent searches", color = TextSecondary, fontSize = 16.sp)
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(historyList) { history ->
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = BackgroundLight,
                        border = androidx.compose.foundation.BorderStroke(1.dp, BorderColor),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onSelectHistory(history) }
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = history.query.ifBlank { "Anywhere" },
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary
                                )
                                Text(
                                    text = "${history.checkIn} - ${history.checkOut} • ${history.adults} Adults",
                                    fontSize = 12.sp,
                                    color = TextSecondary
                                )
                            }
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                                contentDescription = "Search",
                                tint = PrimaryPurple,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SortFilterDialog(
    sortOptions: Map<String, String>,
    currentSort: String?,
    currentMinPrice: Double?,
    currentMaxPrice: Double?,
    onApply: (String?, Double?, Double?) -> Unit,
    onDismiss: () -> Unit
) {
    var selectedSort by remember { mutableStateOf(currentSort) }
    var minPriceStr by remember { mutableStateOf(currentMinPrice?.let { if (it % 1.0 == 0.0) it.toInt().toString() else it.toString() } ?: "") }
    var maxPriceStr by remember { mutableStateOf(currentMaxPrice?.let { if (it % 1.0 == 0.0) it.toInt().toString() else it.toString() } ?: "") }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(24.dp),
            color = Color.White,
            modifier = Modifier
                .fillMaxWidth()
                .wrapContentHeight()
        ) {
            Column {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(PrimaryPurple)
                        .padding(20.dp)
                ) {
                    Text(
                        text = "Sort & Filter",
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                        color = Color.White,
                        modifier = Modifier.align(Alignment.CenterStart)
                    )
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Close",
                        tint = Color.White,
                        modifier = Modifier
                            .align(Alignment.CenterEnd)
                            .size(22.dp)
                            .clickable { onDismiss() }
                    )
                }

                Column(modifier = Modifier.padding(20.dp)) {
                    Text("Sort By", fontWeight = FontWeight.Bold, color = TextPrimary)
                    Spacer(modifier = Modifier.height(8.dp))
                    sortOptions.forEach { (label, value) ->
                        val isSelected = selectedSort == value
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                                .background(
                                    color = if (isSelected) PrimaryPurpleLight else Color.Transparent,
                                    shape = RoundedCornerShape(12.dp)
                                )
                                .clickable { selectedSort = value }
                                .padding(horizontal = 12.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(label, modifier = Modifier.weight(1f), color = TextPrimary, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal)
                            if (isSelected) {
                                Icon(Icons.Default.Check, contentDescription = "Selected", tint = PrimaryPurple, modifier = Modifier.size(18.dp))
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Text("Price Range", fontWeight = FontWeight.Bold, color = TextPrimary)
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = minPriceStr,
                            onValueChange = { minPriceStr = it },
                            label = { Text("Min Price") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = maxPriceStr,
                            onValueChange = { maxPriceStr = it },
                            label = { Text("Max Price") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    Button(
                        onClick = {
                            val min = minPriceStr.toDoubleOrNull()
                            val max = maxPriceStr.toDoubleOrNull()
                            onApply(selectedSort, min, max)
                        },
                        modifier = Modifier.fillMaxWidth().height(48.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = PrimaryPurple),
                        shape = RoundedCornerShape(50)
                    ) {
                        Text("Apply Filters", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun SearchableDropdownDialog(
    title: String,
    items: List<String>,
    onItemSelected: (String) -> Unit,
    onDismiss: () -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = Color.White,
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(max = 500.dp)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text(title, fontWeight = FontWeight.Bold, fontSize = 18.sp, color = TextPrimary)
                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("Search...") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(12.dp))

                val filteredItems = items.filter { it.contains(searchQuery, ignoreCase = true) }

                LazyColumn(modifier = Modifier.weight(1f, fill = false)) {
                    items(filteredItems) { item ->
                        Text(
                            text = item,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onItemSelected(item) }
                                .padding(vertical = 12.dp, horizontal = 4.dp),
                            color = TextPrimary
                        )
                        HorizontalDivider(color = BorderColor)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                TextButton(onClick = onDismiss, modifier = Modifier.align(Alignment.End)) {
                    Text("Cancel", color = TextSecondary)
                }
            }
        }
    }
}
