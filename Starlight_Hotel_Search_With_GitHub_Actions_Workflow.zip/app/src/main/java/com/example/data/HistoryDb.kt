package com.example.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "search_history")
data class SearchHistory(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val query: String,
    val country: String,
    val currency: String,
    val checkIn: String,
    val checkOut: String,
    val adults: Int,
    val children: Int,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "wishlist")
data class SavedHotel(
    @PrimaryKey val hotelRef: String,
    val name: String,
    val address: String?,
    val imageUrl: String?,
    val rating: Double?,
    val reviewCount: Int?,
    val nightlyPriceDisplay: String?,
    val currency: String?,
    val savedAt: Long = System.currentTimeMillis()
)

@Dao
interface SearchHistoryDao {
    @Query("SELECT * FROM search_history GROUP BY query, country, checkIn, checkOut ORDER BY timestamp DESC LIMIT 20")
    fun getRecentHistory(): Flow<List<SearchHistory>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertHistory(history: SearchHistory)

    @Query("DELETE FROM search_history WHERE query = :query AND country = :country AND checkIn = :checkIn AND checkOut = :checkOut")
    suspend fun deleteDuplicate(query: String, country: String, checkIn: String, checkOut: String)

    @Query("DELETE FROM search_history")
    suspend fun clearHistory()
}

@Dao
interface WishlistDao {
    @Query("SELECT * FROM wishlist ORDER BY savedAt DESC")
    fun getWishlist(): Flow<List<SavedHotel>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWishlist(hotel: SavedHotel)

    @Query("DELETE FROM wishlist WHERE hotelRef = :hotelRef")
    suspend fun deleteWishlist(hotelRef: String)

    @Query("SELECT EXISTS(SELECT 1 FROM wishlist WHERE hotelRef = :hotelRef)")
    suspend fun isHotelSaved(hotelRef: String): Boolean
}

@Database(entities = [SearchHistory::class, SavedHotel::class], version = 2, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun searchHistoryDao(): SearchHistoryDao
    abstract fun wishlistDao(): WishlistDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "starlight_hotel_db"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}

class HistoryRepository(
    private val searchHistoryDao: SearchHistoryDao,
    private val wishlistDao: WishlistDao
) {
    val recentHistory: Flow<List<SearchHistory>> = searchHistoryDao.getRecentHistory()
    val wishlist: Flow<List<SavedHotel>> = wishlistDao.getWishlist()

    suspend fun insert(history: SearchHistory) {
        searchHistoryDao.deleteDuplicate(history.query, history.country, history.checkIn, history.checkOut)
        searchHistoryDao.insertHistory(history)
    }

    suspend fun clear() {
        searchHistoryDao.clearHistory()
    }

    suspend fun toggleWishlist(hotel: SavedHotel): Boolean {
        return if (wishlistDao.isHotelSaved(hotel.hotelRef)) {
            wishlistDao.deleteWishlist(hotel.hotelRef)
            false
        } else {
            wishlistDao.insertWishlist(hotel)
            true
        }
    }

    suspend fun isSaved(hotelRef: String): Boolean {
        return wishlistDao.isHotelSaved(hotelRef)
    }
}
