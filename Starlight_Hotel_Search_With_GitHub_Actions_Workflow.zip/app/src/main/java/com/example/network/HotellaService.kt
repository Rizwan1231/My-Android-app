package com.example.network

import com.example.network.models.PricesResponse
import com.example.network.models.SearchRequest
import com.example.network.models.SearchResponse
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.POST
import retrofit2.http.Path
import retrofit2.http.Query

interface HotellaService {
    @POST("api/v1/hotels/search")
    suspend fun searchHotels(
        @Header("X-API-Key") apiKey: String?,
        @Body request: SearchRequest
    ): SearchResponse

    @GET("api/v1/hotels/search/{search_id}")
    suspend fun getSearchPage(
        @Header("X-API-Key") apiKey: String?,
        @Path("search_id") searchId: String,
        @Query("page") page: Int
    ): SearchResponse

    @GET("api/v1/hotels/search/{search_id}/hotels/{hotel_ref}/prices")
    suspend fun getHotelPrices(
        @Header("X-API-Key") apiKey: String?,
        @Path("search_id") searchId: String,
        @Path("hotel_ref") hotelRef: String
    ): PricesResponse
}
