package com.example.network

object ApiConfig {
    const val HOTELLA_BASE_URL = "https://google-hotel-fda8bnc7baafg8cv.canadacentral-01.azurewebsites.net/"
    const val HOTELLA_API_KEY = "fb728f3fad13c6984d80c02232618957db77f260c93a445a7079dcb10c68c61d"
}
