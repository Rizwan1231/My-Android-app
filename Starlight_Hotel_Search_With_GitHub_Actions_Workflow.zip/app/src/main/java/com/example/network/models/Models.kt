package com.example.network.models

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class SearchRequest(
    val query: String,
    @Json(name = "check_in") val checkIn: String,
    @Json(name = "check_out") val checkOut: String,
    val adults: Int = 2,
    val children: Int = 0,
    val currency: String = "USD",
    val locale: String = "en",
    val country: String = "us",
    val page: Int = 1,
    @Json(name = "page_size") val pageSize: Int = 20,
    @Json(name = "pagination_mode") val paginationMode: String = "lazy",
    @Json(name = "sort") val sortBy: String? = null,
    @Json(name = "min_price") val minPrice: Double? = null,
    @Json(name = "max_price") val maxPrice: Double? = null
)

@JsonClass(generateAdapter = true)
data class SearchResponse(
    @Json(name = "search_id") val searchId: String,
    @Json(name = "cache_hit") val cacheHit: Boolean,
    val pagination: Pagination?,
    val hotels: List<Hotel>
)

@JsonClass(generateAdapter = true)
data class Pagination(
    val page: Int,
    @Json(name = "total_items") val totalItems: Int,
    @Json(name = "total_pages") val totalPages: Int,
    @Json(name = "has_next") val hasNext: Boolean,
    @Json(name = "has_previous") val hasPrevious: Boolean,
    @Json(name = "unfiltered_total") val unfilteredTotal: Int? = null,
    @Json(name = "source_total") val sourceTotal: Int? = null,
    @Json(name = "total_is_complete") val totalIsComplete: Boolean? = null,
    @Json(name = "filters_active") val filtersActive: Boolean? = null
)

@JsonClass(generateAdapter = true)
data class Hotel(
    val name: String,
    @Json(name = "hotel_ref") val hotelRef: String?,
    @Json(name = "google_entity_key") val googleEntityKey: String?,
    val rating: Double?,
    @Json(name = "review_count") val reviewCount: Int?,
    val price: Double?,
    val currency: String?,
    val address: String?,
    @Json(name = "image_url") val imageUrl: String?,
    @Json(name = "view_prices_url") val viewPricesUrl: String?,
    @Json(name = "prices_api_url") val pricesApiUrl: String?,
    @Json(name = "property_type") val propertyType: String? = null,
    val map: MapInfo? = null,
    @Json(name = "total_price") val totalPrice: Double? = null,
    @Json(name = "nightly_price_display") val nightlyPriceDisplay: String? = null
)

@JsonClass(generateAdapter = true)
data class MapInfo(
    @Json(name = "google_maps_embed_url") val googleMapsEmbedUrl: String?,
    val latitude: Double? = null,
    val longitude: Double? = null
)

@JsonClass(generateAdapter = true)
data class PricesResponse(
    val success: Boolean,
    @Json(name = "booking_options") val bookingOptions: List<BookingOption>?
)

@JsonClass(generateAdapter = true)
data class BookingOption(
    val provider: String,
    @Json(name = "provider_logo_url") val providerLogoUrl: String?,
    @Json(name = "booking_url") val bookingUrl: String,
    @Json(name = "stay_total_display") val stayTotalDisplay: String?,
    @Json(name = "nightly_price_display") val nightlyPriceDisplay: String?
)
