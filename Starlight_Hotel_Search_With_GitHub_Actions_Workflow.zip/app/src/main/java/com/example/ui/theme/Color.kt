package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val PrimaryPurple = Color(0xFF5B32D6)
val PrimaryPurpleLight = Color(0xFFF0ECFF)
val PrimaryPurpleDark = Color(0xFF3F1DA8)

val HeroGradientStart = Color(0xFF130E3B)
val HeroGradientEnd = Color(0xFF2D1860)

val BackgroundLight = Color(0xFFF7F8FC)
val CardBackground = Color.White
val TextPrimary = Color(0xFF1E1B3A)
val TextSecondary = Color(0xFF757490)
val BorderColor = Color(0xFFEBEBF5)

val AccentOrange = Color(0xFFFF6D00)
val AccentBadgeBg = Color(0xFFFFF3E0)
val StarYellow = Color(0xFFFFB300)

val PillSelectedBg = Color(0xFFF0ECFF)
val PillSelectedText = Color(0xFF5B32D6)
val PillUnselectedBg = Color(0xFFF2F3F7)
val PillUnselectedText = Color(0xFF6E6E82)
